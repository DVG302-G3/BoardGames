package tictactoe.run;

import game.init.Runner;
import tictactoe.impl.TttGameState;
import tictactoe.io.TttConsoleIoFactory;

/**
 *
 * @author thomas
 */
public class ConsoleRunner {

    public static void main(String[] args) {
        new Runner(new TttGameState(), new TttConsoleIoFactory()).run();
    }
}
